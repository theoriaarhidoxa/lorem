import {ActionTypes} from "../constants/actionTypes";

export const setList = list => {
    return {
        type: ActionTypes.SET_LIST,
        payload: list
    }
};

export const removeItemFromList = id => {
  return {
      type: ActionTypes.REMOVE_ITEM_FROM_LIST,
      payload: id
  }
};
