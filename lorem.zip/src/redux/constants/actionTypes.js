export const ActionTypes = {
    SET_LIST: 'SET_LIST',
    REMOVE_ITEM_FROM_LIST: 'REMOVE_ITEM_FROM_LIST'
};
