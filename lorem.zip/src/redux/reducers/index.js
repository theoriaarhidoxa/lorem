import {combineReducers} from 'redux';
import {ListReducer} from "./ListReducer";

export const reducers = combineReducers({
    totalList: ListReducer
});
