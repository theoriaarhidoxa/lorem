import {ActionTypes} from "../constants/actionTypes";

const initialState = {
    list: []
};

export const ListReducer = (state = initialState, action) => {
    switch (action.type) {
        case ActionTypes.SET_LIST:
            return {...state, list: action.payload};
        case ActionTypes.REMOVE_ITEM_FROM_LIST:
            return {...state, list: state.list.filter(el => el.fbId !== action.payload)};
        default:
            return state;
    }
};
