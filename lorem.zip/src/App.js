import React from "react";
import {BrowserRouter, HashRouter, Switch, Route} from "react-router-dom";
import Form from "./templates/Form";
import Saved from "./templates/Saved";


function App() {
    return (
        <HashRouter>
            <Switch>
                <Route path='/' exact component={Form} />
                <Route path='/list' component={Saved} />
            </Switch>
        </HashRouter>
    )
}

export default App;
