import React, {useEffect} from 'react';
import {useHistory} from 'react-router-dom';
import './Saved.scss';
import {useDispatch, useSelector} from "react-redux";
import {removeItemFromList, setList} from "../redux/actions/loremActions";
import {Strings} from "../constants";

const Saved = () => {

    const dispatch = useDispatch();
    const saved = useSelector(state => state['totalList']['list']);

    const getSaved = async () => {
        const res = await fetch(`${Strings.DATABASE_ROOT}.json`);
        const data = await res.json();
        if (data) {
            const arr = Object.entries(data).map(el => {
                const res = {...el[1]};
                res.fbId = el[0];
                return res;
            });
            dispatch(setList(arr));
        }
    };

    useEffect(() => {
        getSaved().then();
    }, []);

    const history = useHistory();

    const handleRemove = id => {
        fetch(`${Strings.DATABASE_ROOT}/${id}.json`, {method: 'DELETE'}).then(() => {
            dispatch(removeItemFromList(id));
        });
    };

    return (
        <div className='wrap'>
            <button onClick={() => history.push('/')}>Вернуться</button>
            {saved.length > 0 ? <ul>
                {saved.map((el, i) => {
                    const {id, fbId, title} = el;
                    return (
                        <li key={id}>
                            <div><b>{i + 1}.</b> {title}</div>
                            <p><span>{new Date(id).toString().substring(16, 24)}</span> <i
                                onClick={() => handleRemove(fbId)}>&#9762;</i></p></li>
                    )
                })}

            </ul> : <h1>Записей нет</h1>}
        </div>
    );
};

export default Saved;
