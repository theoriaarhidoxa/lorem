import React, {useState, useEffect} from 'react';

const Modal = ({onCancel, onConfirm}) => {

    const [userInput, setUserInput] = useState('');
    const [result, setResult] = useState(null);
    const [alert, setAlert] = useState(false);

    const operations = ['+', '-', '*'];
    const [term1] = useState(Math.floor(Math.random() * 10));
    const [term2] = useState(Math.floor(Math.random() * 10));
    const [currentOperationIndex] = useState(Math.floor(Math.random() * operations.length));
    const [currentOperation] = useState(operations[currentOperationIndex]);

    const calculateCurrentResult = (value1, value2, op) => {
        switch (op) {
            case '+':
                return value1 + value2;
            case '-':
                return value1 - value2;
            case '*':
                return value1 * value2;
        }
    };

    useEffect(() => {
        setResult(calculateCurrentResult(term1, term2, currentOperation));
    }, []);

    const handleUserInput = () => {
        const testPassed = +userInput === result;
        onConfirm(testPassed);
        setAlert(!testPassed);
    };

    return (
        <>
            <div className='overlay' onClick={() => onCancel()}/>
            <div className='modal'>
                <h2>F.A.S <span>(Firebase AntiSpam System)</span></h2>
                <div className='captcha'>
                    <p>{term1} {currentOperation} {term2} = </p>
                    <input type='text' value={userInput} onChange={e => setUserInput(e.target.value)}/>
                    <input type='button' value='Отправить' onClick={handleUserInput}/>
                </div>
                {alert && <p className='modal__alert'>Ошибка. Попробуйте ещё раз.</p>}
            </div>
        </>
    );
};

export default Modal;
