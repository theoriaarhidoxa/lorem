import React, {useState} from 'react';
import items from "../data";
import {useHistory} from 'react-router-dom';
import Alert from "./Alert";
import {Strings} from "../constants";

const Form = () => {
    const [textLength, setTextLength] = useState(1);
    const [error, setError] = useState(false);
    const [textContent, setTextContent] = useState('');
    const [alert, setAlert] = useState(false);
    const history = useHistory();

    const entriesLimit = 10;

    const handleTextSize = e => {
        let input = e.target.value;
        if (input === '0') {
            setError(true);
        } else if (+input > entriesLimit) {
            setError(true);
            setTextLength(entriesLimit);
            return;
        } else if (input < 1) {
            input *= -1;
            setError(false);
        } else {
            setError(false);
        }
        setTextLength(input);
    };


    const handleSubmit = e => {
        e.preventDefault();
        const chunk = [];
        let prev = null, count = 0;

        while (count < textLength) {
            const rand = Math.floor(Math.random() * items.length);
            if (rand !== prev) {
                chunk.push(items[rand]);
                prev = rand;
                count++;
            }
        }
        setTextContent(chunk.join('<br /><br />'));
    };


    const handleClear = async () => {
        setTextContent('');
        setTextLength(1);
    };

    const handleSave = () => {
        const cut = textContent.indexOf('</b>');
        const data = {
            id: new Date(),
            title: cut > 0 && cut < 400 ? textContent.substring(0, cut).replace('<b>', '').replace('/\<br \/\>/g', '') : 'No title'
        };
        fetch(`${Strings.DATABASE_ROOT}.json`, {
            method: 'POST',
            body: JSON.stringify(data),
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(() => {
            setAlert(true);
            setTimeout(() => {
                setAlert(false);
            }, 1500);
        });
    };

    return (
        <>
            <div className="wrap">
                <p>Lorem-генератор случайных абзацев текста с Coding Addict.<br />
                    С добавлением redux и сохранением краткой информации о сгенерированном чанке (по&nbsp;желанию). Бекэнд со списком - на firebase.</p><br />

                <form onSubmit={handleSubmit}>
                    <label>Количество абзацев</label>
                    <input className={error ? 'error' : ''} type="number" value={textLength} onChange={handleTextSize}/>
                    <input type='submit' value='Создать' disabled={error} />
                    <input type='button' className={textContent ? 'animated' : ''} disabled={!textContent || alert}
                           value='Сохранить' onClick={handleSave}/>
                </form>
                {<div dangerouslySetInnerHTML={{__html: textContent}}/>}
                <input type='button' disabled={!textContent || alert} value='Очистить' onClick={handleClear}/>&nbsp;
                <input type='button' disabled={alert} value='Просмотр сохранённых записей' onClick={() => history.push('/list')}/>
            </div>
            <Alert visible={alert}/>
        </>
    );
};

export default Form;
