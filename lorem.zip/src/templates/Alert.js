import React from 'react';

const Alert = ({visible}) => {
    return (
        <div className={visible ? 'alert visible' : 'alert'}>
            <p>Записи обновляются...</p>
        </div>
    );
};

export default Alert;
