export const Strings = {
    DATABASE_ROOT: 'https://ca-lorem-default-rtdb.europe-west1.firebasedatabase.app/entries'
};
